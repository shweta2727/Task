import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {AddEmpService} from '../service/add-emp.service';
import {Employee} from '../employee';
import {ActivatedRoute} from '@angular/router';
import { Observable } from 'rxjs/Observable';
import {Location} from '@angular/common';

@Component({
  selector: 'app-update-emp',
  templateUrl: './update-emp.component.html',
  styleUrls: ['./update-emp.component.css']
})
export class UpdateEmpComponent implements OnInit {
  emp :Employee;
  add1:string;
  
  name = new FormControl('', [
    Validators.required,
    Validators.minLength(4)
  ]);
  nm:string;
  ph:string;
  ad1:string;
  ad2:string;
  cy:string;
  pstlCode:string;

  phone = new FormControl('', [
    Validators.required,
    Validators.pattern('[0-9]+')
  ]);
  city = new FormControl('');
  address1 = new FormControl('');
  address2 = new FormControl('');
  postalcode = new FormControl('');
  updateForm: FormGroup = this.builder.group({
  name: this.name,
  phone :this.phone,
  city:this.city,
  address1:this.address1,
  address2:this.address2,
  postalcode:this.postalcode
  });
  id:number;
  constructor(private builder: FormBuilder, private addEmpService :AddEmpService, private route:ActivatedRoute, private _location:Location) { }
  ngOnInit() {
    this.id = this.route.snapshot.params.id;
    console.log(this.id);
    this.getEmp(this.id);
    
  }
  getEmp(id){
    this.addEmpService.getEmp(this.id).subscribe((data)=>
    {console.log(data);
    this.emp = data.json();
    console.log(this.emp);
    this.nm=this.emp.name;
    this.ph= this.emp.phone;
    this.cy =this.emp.address.city;
    this.ad1= this.emp.address.address_line1;
    this.ad2=this.emp.address.address_line2;
    this.pstlCode =this.emp.address.postal_code;
    });
    console.log(this.emp);
  }
  updateEmp(emp){
   var name =this.updateForm.get('name').value;
   var phone =this.updateForm.get('phone').value;
   var city =this.updateForm.get('city').value;
  
   var address_line1 =this.updateForm.get('address1').value;
   var address_line2 =this.updateForm.get('address2').value;
   var postal_code =this.updateForm.get('postalcode').value;
   this.emp =new Employee(this.id, name, phone, city, address_line1, address_line2, postal_code  );
   this.addEmpService.updateEmployees(this.emp);
  }

  back(){
    this._location.back();
  }

}
