import { Component, OnInit } from '@angular/core';
import { Validators, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {AddEmpService} from '../service/add-emp.service';
import {Employee} from '../employee';
import {Location} from '@angular/common';

@Component({
  selector: 'app-add-emp',
  templateUrl: './add-emp.component.html',
  styleUrls: ['./add-emp.component.css']
})
export class AddEmpComponent implements OnInit {
  emp :Employee;
  add1:string;
  name = new FormControl('', [
    Validators.required,
    Validators.minLength(4)
  ]);
  phone = new FormControl('', [
    Validators.required,
    Validators.pattern('[0-9]+')
  ]);
  city = new FormControl('');
  address1 = new FormControl('');
  address2 = new FormControl('');
  postalcode = new FormControl('');
  addForm: FormGroup = this.builder.group({
    name: this.name,
    phone :this.phone,
    
    city:this.city,
    address1:this.address1,
    address2:this.address2,
    postalcode:this.postalcode
  });
  constructor(private builder: FormBuilder, private addEmpService :AddEmpService,private _location:Location) { }

  ngOnInit() {
  }
  addEmp()
  {
 
   var name =this.addForm.get('name').value;
   var phone =this.addForm.get('phone').value;
   var city =this.addForm.get('city').value;
  
   var address_line1 =this.addForm.get('address1').value;
   var address_line2 =this.addForm.get('address2').value;
   var postal_code =this.addForm.get('postalcode').value;
   this.emp =new Employee(2, name, phone, city, address_line1, address_line2, postal_code  );
   this.addEmpService.addEmployees(this.emp);
  }
  back(){
    this._location.back();
  }

}
