import { Injectable } from '@angular/core';
import {Http, Headers, Request, Response, RequestOptions} from '@angular/http';
import {Employee} from '../employee';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/map';


@Injectable()
export class AddEmpService {
  url="http://localhost:3000/data";
  emp:Employee[];
  maxId:number=0;
  statusCode:number;
  status:boolean;
  constructor(private _http:Http) { }
addEmployees(emp){
  let headers = new Headers({ 'Content-Type': 'application/json' });
  let options = new RequestOptions({ headers:headers });
  this._http.get(this.url).subscribe((data)=>
  { this.emp = data.json();
    this.maxId = this.emp[0].id;
    for(var i=0 ; i<this.emp.length; i++){
    if(this.emp[i].id>this.maxId){
    this.maxId=this.emp[i].id;
    }
  }
  emp.id = this.maxId+1;
  this._http.post(this.url, emp, options ).subscribe((data)=>{},
  (error:any)=>{console.log(error.status);
    console.log(error);
  this.statusCode=error.status;
console.log(this.statusCode)});
  });
}
getEmp(id):Observable<Response>{
 return  this._http.get(this.url+ '/'+ id);
  }
  updateEmployees(emp){
    let headers = new Headers();
    headers.append('Content-Type', 'application/json');
    let url = `${this.url}/${emp.id}`;
    return this._http.put(url, JSON.stringify(emp), {headers: headers}).map((res:any)=>res.json()).subscribe((data)=>{
      this.status = this.handleResponse(data.header)
    },
    (error)=>{console.log(error)});
  
  }
  handleResponse(header) {
   return true;
}
}
