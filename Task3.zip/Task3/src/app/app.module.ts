import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {HttpClientModule} from '@angular/common/http';
import {HttpModule} from '@angular/http';
import { FormsModule,ReactiveFormsModule}   from '@angular/forms';
import {RouterModule, Routes} from '@angular/router';
import {AddEmpService} from './service/add-emp.service';




import { AppComponent } from './app.component';
import { ListEmployeesComponent } from './list-employees/list-employees.component';
import { NapipPipe } from './napip.pipe';
import { AddEmpComponent } from './add-emp/add-emp.component';
import { UpdateEmpComponent } from './update-emp/update-emp.component';
import { HeaderComponent } from './header/header.component';


const routes: Routes = [
  { path: 'employees/add', component: AddEmpComponent },
  { path: '' , component:ListEmployeesComponent},
  { path: 'employees/:id/edit' , component:UpdateEmpComponent},
  { path: 'listEmp' , component:ListEmployeesComponent},
  
];

@NgModule({
  declarations: [
    AppComponent,
    ListEmployeesComponent,
    NapipPipe,
    AddEmpComponent,
    UpdateEmpComponent,
    HeaderComponent

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    HttpModule,
    RouterModule.forRoot(routes),
    ReactiveFormsModule
  ],
  providers: [AddEmpService],
  bootstrap: [AppComponent]
})
export class AppModule { }
