import { NapipPipe } from './napip.pipe';

describe('NapipPipe', () => {
  it('create an instance', () => {
    const pipe = new NapipPipe();
    expect(pipe).toBeTruthy();
  });
});
